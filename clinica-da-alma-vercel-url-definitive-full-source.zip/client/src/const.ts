export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

const LOCAL_LOGIN_FALLBACK = "/";

const isConfiguredEnvValue = (value: unknown): value is string => {
  if (typeof value !== "string") return false;
  const normalized = value.trim();
  return Boolean(normalized) && normalized !== "undefined" && normalized !== "null";
};

// Generate the login URL lazily and defensively so a missing Vite env var never
// breaks the public frontend during initial render on Vercel.
export const getLoginUrl = () => {
  const oauthPortalUrl = import.meta.env.VITE_OAUTH_PORTAL_URL;
  const appId = import.meta.env.VITE_APP_ID;

  if (!isConfiguredEnvValue(oauthPortalUrl) || !isConfiguredEnvValue(appId)) {
    return LOCAL_LOGIN_FALLBACK;
  }

  try {
    const redirectUri = `${window.location.origin}/api/oauth/callback`;
    const state = btoa(redirectUri);
    const baseUrl = oauthPortalUrl.endsWith("/") ? oauthPortalUrl : `${oauthPortalUrl}/`;
    const url = new URL("app-auth", baseUrl);

    url.searchParams.set("appId", appId);
    url.searchParams.set("redirectUri", redirectUri);
    url.searchParams.set("state", state);
    url.searchParams.set("type", "signIn");

    return url.toString();
  } catch (error) {
    console.warn("[Auth] Invalid OAuth portal configuration; using local fallback.", error);
    return LOCAL_LOGIN_FALLBACK;
  }
};
