# Correção Vercel + Supabase

Este pacote contém os arquivos atualizados para corrigir o erro de inicialização no deploy da Vercel.

## Arquivos incluídos

- `client/src/const.ts`: impede `new URL("undefined/app-auth")` quando `VITE_OAUTH_PORTAL_URL` ou `VITE_APP_ID` não estiverem definidos.
- `client/src/lib/supabase.ts`: centraliza a configuração frontend do Supabase usando `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`.
- `server/_core/env.ts`: mantém compatibilidade no backend com `VITE_SUPABASE_URL`/`VITE_SUPABASE_ANON_KEY` e também `SUPABASE_URL`/`SUPABASE_ANON_KEY`.
- `fix-vercel-supabase-env.patch`: patch completo do commit local para aplicação manual.

## Como aplicar manualmente

Copie as pastas `client` e `server` deste ZIP para a raiz do repositório `clinica-da-alma-system`, substituindo os arquivos existentes.

Depois rode:

```bash
pnpm install
pnpm run check
pnpm run build
git add client/src/const.ts client/src/lib/supabase.ts server/_core/env.ts
git commit -m "Fix frontend env handling for Vercel deploy"
git push origin main
```

## Variáveis necessárias na Vercel

No projeto da Vercel, confirme em **Settings > Environment Variables**:

```env
VITE_SUPABASE_URL=https://SEU-PROJETO.supabase.co
VITE_SUPABASE_ANON_KEY=SUA_CHAVE_ANON_PUBLICA
```

As variáveis `VITE_*` precisam existir no ambiente de build da Vercel para serem incorporadas ao frontend. Após alterar variáveis, faça novo deploy.
